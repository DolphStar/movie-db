// Normally api keys are kept secret, but for demo purposes I will leave this here.
export const apiKey = "9de5ef6478cb7a1b5b666488d964d267";

export const appTitle = "Movie Time";
export const youtubeApiKey = "AIzaSyBgitWTtZ1hFrkPFDWfvHfOOuTIdQ-fbxg";

export const imgPath = "https://image.tmdb.org/t/p/original";

export const MOVIE_START = "https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=en-US";

export const VIDEO_START = "https://api.themoviedb.org/3/movie/";

export const SEARCH_START = "https://api.themoviedb.org/3/search/movie?include_adult=false&language=en-US&";

export const youtubePath = "https://www.youtube.com/embed/";

// Range of pages that trailr will choose from
export const moviePage = 10;

export const firebaseConfig = {
  apiKey: "AIzaSyCOrtwzJP4I2Xi7mfOBx1qiqSN9Q8MlraM",
  authDomain: "trailr-be84b.firebaseapp.com",
  projectId: "trailr-be84b",
  storageBucket: "trailr-be84b.appspot.com",
  messagingSenderId: "1096065471677",
  appId: "1:1096065471677:web:1cbf71f9839de157da13d4"
};
